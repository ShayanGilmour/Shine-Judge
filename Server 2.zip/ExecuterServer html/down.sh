echo "Sorry, this webpage is down. Please try again later." > /var/www/html/result
