<html>
<head>
<link rel="stylesheet" href="css.css" type="text/css">
<!--
<meta name="viewport" content="width=device-width, initial-scale=1.0">
-->
<style>

.button {
  background-color: #999999;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.grid-container {
  display: grid;
  grid-template-columns: 150px auto 500px;
  grid-template-rows: auto;
  margin-top: 5px;
  grid-gap: 3px;
  background-color: #ffffff;
  padding: 3px;
}

.grid-container > div {
  background-color: rgba(255, 255, 255, 0.8);
  text-align: center;
  padding: 20px 0;
  font-size: 30px;
}

.leftDiv {

  border: 0px solid red;
  margin: 1px;
  font-size: 20px;
  height: 80px;
  line-height: 1;
  text-align: center;
  vertical-align: middle;
  display: flex;
  justify-content: center;
  align-items: center;

  cursor:pointer;

}

.rightDiv {

  border: 0px solid red;
  margin: 1px;
  text-align: center;
  vertical-align: middle;
  font-size: 20px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;

  cursor:pointer;
}

.Architect {

  border: 0px solid red;
  margin: 1px;
  font-size: 20px;
  height: 50px;
  line-height: 1;
  text-align: center;
  vertical-align: middle;
  display: flex;
  justify-content: center;
  align-items: center;

}

.Mission {

  border: 0px solid red;
  margin: 1px;
  text-align: center;
  vertical-align: middle;
  font-size: 20px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
}



hr {
  margin-top: 0px;
  margin-bottom: 0px;
}

</style>
</head>
<body>

<?php

    shell_exec("./tahlil.out &> /var/www/html/Log");


?>

<center>
<p style="font-size:40px">Mission Statement Quiz</p>
<p style="font-size:40px"> <?php readfile("/var/www/html/tahlil.txt"); ?>  <p>



</center>


<script>
function redirect() {
  location.replace("http://103.216.63.84/");
}
</script>



</body>
</html>

