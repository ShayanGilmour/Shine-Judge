<html>
<body>



<?php

    $InUse = "/var/www/html/InUse";
    $x = 0;
    while(x <= 15) {
	if (!file_exists($InUse)) {
	    break;
	}
        $x++;
	if ($x == 15) {
		header('Location: /errors/error_timeout.html');
		exit();
	}
	sleep(0.5);
    }


    shell_exec("echo 1 >> /var/www/html/InUse");
    $file = "/var/www/html/newSub";
    file_put_contents($file,$_POST["ans"]);


    shell_exec("./a.out < newSub &> /var/www/html/Log");

    $file = file_get_contents('Result', true);
    echo $file;

    shell_exec("rm /var/www/html/InUse");

?>



</body>
</html>
