<html>
<head>
<link rel="stylesheet" href="css.css" type="text/css">
<!--
<meta name="viewport" content="width=device-width, initial-scale=1.0">
-->
<style>

.button {
  background-color: #999999;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.grid-container {
  display: grid;
  grid-template-columns: 150px auto 500px;
  grid-template-rows: auto;
  margin-top: 5px;
  grid-gap: 3px;
  background-color: #ffffff;
  padding: 3px;
}

.grid-container > div {
  background-color: rgba(255, 255, 255, 0.8);
  text-align: center;
  padding: 20px 0;
  font-size: 30px;
}

.leftDiv {

  border: 0px solid red;
  margin: 1px;
  font-size: 20px;
  height: 80px;
  line-height: 1;
  text-align: center;
  vertical-align: middle;
  display: flex;
  justify-content: center;
  align-items: center;

  cursor:pointer;

}

.rightDiv {

  border: 0px solid red;
  margin: 1px;
  text-align: center;
  vertical-align: middle;
  font-size: 20px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;

  cursor:pointer;
}

.Architect {

  border: 0px solid red;
  margin: 1px;
  font-size: 20px;
  height: 50px;
  line-height: 1;
  text-align: center;
  vertical-align: middle;
  display: flex;
  justify-content: center;
  align-items: center;

}

.Mission {

  border: 0px solid red;
  margin: 1px;
  text-align: center;
  vertical-align: middle;
  font-size: 20px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
}



hr {
  margin-top: 0px;
  margin-bottom: 0px;
}

</style>
</head>
<body>

<?php

    $InUse = "/var/www/html/InUse";
    $x = 0;
    while(x <= 15) {
        if (!file_exists($InUse)) {
            break;
        }
        $x++;
        if ($x == 15) {
                header('Location: /errors/error_timeout.html');
                exit();
        }
        sleep(0.5);
    }


    shell_exec("echo 1 >> /var/www/html/InUse");
    $file = "/var/www/html/newSub";

    $write = $_POST["ans"].$_POST["name"];

    file_put_contents($file, $write);


    shell_exec("./a.out < newSub &> /var/www/html/Log");

    $file = file_get_contents('Result', true);
//    echo $file;

    shell_exec("rm /var/www/html/InUse");

?>

<center>
<p style="font-size:40px">Mission Statement Quiz</p>
<p style="font-size:40px"><br><br>Submited!<p>

<button class ="button" onclick="redirect()">Go to the first page</button>


</center>


<script>
function redirect() {
  location.replace("http://103.216.63.84/");
}
</script>



</body>
</html>

