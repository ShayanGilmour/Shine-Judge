#include <bits/stdc++.h>

using namespace std;

int testsTaken, correctAns; 

int ans[15];
int anis[15];

vector <int> newans;

string toString(int x)
{
	string ani = "";
	while (x)
	{
		ani += char(x%10 +'0');
		x/=10;
	}
	
	string kon = "";

	for (int i = ani.size()-1; i > -1; --i)
		kon += ani[i];

	if (kon.size() == 0)
			kon = "0";

	return kon;

}

int main()
{

//	cout << toString(1231230);
//	system ("echo 1 >> YESYES");
	//Answers
	ans[1] = 17;
	ans[2] = 13;
	ans[3] = 23;
	ans[4] = 24;
	ans[5] = 14;
	ans[6] = 21;
	ans[7] = 19;
	ans[8] = 15;
	ans[9] = 22;
	ans[10] = 16;
	ans[11] = 18;
	ans[12] = 20;
	
//	system ("echo 1 >> BEFOREANALIS");	

//	cout << "BEFORE";


	//Analys the new data
	newans.clear();
	newans.push_back(0);
	int tmp;
//	ofstream balls("shit.txt");
	for (int i = 1; i < 13; ++i)
	{
		cin >> tmp;
//		balls << tmp << ' ';
		if (tmp > 24 or tmp < 12)
			return 0;
		newans.push_back(tmp);
	}
	string namer;
	cin >> namer;

//	system ("echo 1 >> LOADING");
	//Load Data
	fstream data("database827364");
	data >> testsTaken;
	data >> correctAns;

	for (int i = 1; i < 13; ++i)
		data >> anis[i];

	testsTaken++;

	data.close();
	
	//Add the new submission
	int correct = 0;
	for (int  i = 1; i < 13; ++i)
	{
		tmp = newans[i];
		if (tmp == ans[i])
			anis[i]++, correctAns++, correct++;
	}

	string fuck = "submissions65/"+ toString(testsTaken) + namer;
	ofstream saveSub(fuck.c_str());
	saveSub << toString(testsTaken) + " " +namer+ " ";
	saveSub << setprecision(3) << (double)correct/12*100 << "% ";
	for ( int i = 1; i < newans.size(); ++i)
		saveSub << newans[i] << ' ';
//	saveSub << namer;
	saveSub.close();
	//system("rm /var/www/html/database827363");
	
	ofstream newdata("database827364");
	newdata << testsTaken << '\n';
	newdata << correctAns << '\n';
	for (int i = 1; i < 13; ++i)
		newdata << anis[i] << '\n';

	newdata.close();
	system("sleep 0.2s");
	
	ofstream result("Result");
	result << setprecision(3) << (double)correct/12*100; result <<'%';
	result.close();



}




