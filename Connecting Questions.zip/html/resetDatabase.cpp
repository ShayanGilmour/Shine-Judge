#include <bits/stdc++.h>
using namespace std;

int main()
{

	system("rm database827364");
	ofstream fout("database827364");

	for (int i = 0; i < 14; ++i)
		fout << 0 << endl;

	fout.close();
}
