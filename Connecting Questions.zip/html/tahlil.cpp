#include <bits/stdc++.h>
using namespace std;

int main()
{
	ifstream data("database827364");
	ofstream tahlil("tahlil.txt");

	int all;
	data >> all;
	int tmp;

	data >> tmp;
	tahlil <<  "Over all " << setprecision(3) << (double)tmp/all << "%" << "<br>" << all << " tests taken<br><br>";
	
	data >>tmp;
	tahlil << "Louis Kahn " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Eero Saarinen " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Frank Lloyd Wright " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Lina Bo Bardi " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Alvar Aalto " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Ludwig Mies Van der Rohe " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Venturi Scott Brown " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Le Corbusier " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "John Portman " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "OMA " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "R. Buckminster Fuller " << setprecision(3) << (double)tmp/all << "%" << "<br>";
        data >>tmp;
        tahlil << "Luis Barragan " << setprecision(3) << (double)tmp/all << "%" << "<br>";

	tahlil.close();

}
