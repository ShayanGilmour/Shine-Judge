<html>
<head>
<link rel="stylesheet" href="css.css" type="text/css">
<!--
<meta name="viewport" content="width=device-width, initial-scale=1.0">
-->
<style>

.button {
  background-color: #999999;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.grid-container {
  display: grid;
  grid-template-columns: 150px auto 500px;
  grid-template-rows: auto;
  margin-top: 5px;
  grid-gap: 3px;
  background-color: #ffffff;
  padding: 3px;
}

.grid-container > div {
  background-color: rgba(255, 255, 255, 0.8);
  text-align: center;
  padding: 20px 0;
  font-size: 30px;
}

.leftDiv {

  border: 0px solid red;
  margin: 1px;
  font-size: 20px;
  height: 80px;
  line-height: 1;
  text-align: center;
  vertical-align: middle;
  display: flex;
  justify-content: center;
  align-items: center;

  cursor:pointer;

}

.rightDiv {

  border: 0px solid red;
  margin: 1px;
  text-align: center;
  vertical-align: middle;
  font-size: 20px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;

  cursor:pointer;
}

.Architect {

  border: 0px solid red;
  margin: 1px;
  font-size: 20px;
  height: 50px;
  line-height: 1;
  text-align: center;
  vertical-align: middle;
  display: flex;
  justify-content: center;
  align-items: center;

}

.Mission {

  border: 0px solid red;
  margin: 1px;
  text-align: center;
  vertical-align: middle;
  font-size: 20px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
}



hr {
  margin-top: 0px;
  margin-bottom: 0px;
}

</style>
</head>
<body>

<?php

    $InUse = "/var/www/html/InUse";
    $x = 0;
    while(x <= 15) {
        if (!file_exists($InUse)) {
            break;
        }
        $x++;
        if ($x == 15) {
                header('Location: /errors/error_timeout.html');
                exit();
        }
        sleep(0.5);
    }


    shell_exec("echo 1 >> /var/www/html/InUse");
    $file = "/var/www/html/newSub";
    file_put_contents($file,$_POST["ans"]);


    shell_exec("./a.out < newSub &> /var/www/html/Log");

    $file = file_get_contents('Result', true);
//    echo $file;

    shell_exec("rm /var/www/html/InUse");

?>


<h1><center><br>You've got <?php echo $file;?></center></h1>

<center>
<div class="container">
<div class="grid-container">

  <div>



	<div class="Architect">Architect</div>
	<hr>
	<div class="leftDiv" onclick="Called('1')" id="t1">Louis<br>Kahn</div>
	<hr>
	<div class="leftDiv" onclick="Called('2')" id="t2">Eero<br>Saarinen</div>
	<hr>
        <div class="leftDiv" onclick="Called('3')" id="t3">Frank Lloyd Wright</div>
        <hr>
        <div class="leftDiv" onclick="Called('4')" id="t4">Lina<br>Bo Bardi</div>
        <hr>
        <div class="leftDiv" onclick="Called('5')" id="t5">Alvar<br>Aalto</div>
        <hr>
        <div class="leftDiv" onclick="Called('6')" id="t6">Ludwig Mies<br>Van der Rohe</div>
        <hr>
        <div class="leftDiv" onclick="Called('7')" id="t7">Venturi Scott Brown</div>
        <hr>
        <div class="leftDiv" onclick="Called('8')" id="t8">Le Corbusier</div>
        <hr>
        <div class="leftDiv" onclick="Called('9')" id="t9">John<br>Portman</div>
        <hr>
        <div class="leftDiv" onclick="Called('10')" id="t10">OMA</div>
        <hr>
        <div class="leftDiv" onclick="Called('11')" id="t11">R. Buckminster Fuller</div>
        <hr>
        <div class="leftDiv" onclick="Called('12')" id="t12">Luis Barragan</div>
        <hr>

  </div>

  <div>
	<canvas id="Canvas" width="194" height="1032" line-height: 1.0;
	style="border:0px solid #c3c3c3;">
	Your browser does not support the canvas element.
	</canvas>
  </div>

  <div>


        <div class="Mission">
        Mission
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('13')" id="t13">
	To create modern ruins, composed using primary shapes, constructed in earthen materials, and rendered in high contrast shadows and light.
	</div>
   	<hr>

        <div class="rightDiv" onclick="Called('14')" id="t14">
        To create landmarks whose form, space and scale are relate to 20th century  high-speed transportation.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('15')" id="t15">
        To combine the heroism of cantilevered structures with the coziness of the Gesamtkunstwerk.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('16')" id="t16">
	To liberate space from structure and to create vast spaces of free assembly.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('17')" id="t17">
        Invent a rustic modernism of organic forms regulated by ergonomic comfort and constructed of raw natural materials.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('18')" id="t18">
        To magically make buildings float and glow using tricks of structure and materials.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('19')" id="t19">
        To reconceive architecture as communicative using photographs and signages in the era of the automobile and advertising.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('20')" id="t20">
        Define spacial principals of new modern architecture in 5 easily copied points.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('21')" id="t21">
        To popularise the experience of vertiginous excitement in interior urban spaces, as an architect and a developer.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('22')" id="t22">
        To diagram a paradox and transform it into a space of irony and controversy.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('23')" id="t23">
        To design prototypical systems constrained by measurable performance criteria.
        </div>
        <hr>

        <div class="rightDiv" onclick="Called('24')" id="t24">
        To create spatial illusions that blur the boundary between indoor and outdoor rooms through the most minimal means of color, light, and reflection.
        </div>
        <hr>


  </div>


</div>
</div>


<!--
<button class ="button" onclick="submit()" id="submit1Button">Submit</button>
<button onclick="submit()" id="submitButton">Submit</button> -->
</center>

<script>
var c = document.getElementById("Canvas");
var ctx = c.getContext("2d");

var ans = {};
ans[1] = 13;
ans[2] = 14;
ans[3] = 15;
ans[4] = 16;
ans[5] = 17;
ans[6] = 18;
ans[7] = 19;
ans[8] = 20;
ans[9] = 21;
ans[10] = 22;
ans[11] = 23;
ans[12] = 24;

var left, right;
left = 0; right = 0;

var pair = {};

var ii = 1;

pair[1] = "<?php echo $_POST[ans1];?>";
pair[2] = "<?php echo $_POST[ans2];?>";
pair[3] = "<?php echo $_POST[ans3];?>";
pair[4] = "<?php echo $_POST[ans4];?>";
pair[5] = "<?php echo $_POST[ans5];?>";
pair[6] = "<?php echo $_POST[ans6];?>";
pair[7] = "<?php echo $_POST[ans7];?>";
pair[8] = "<?php echo $_POST[ans8];?>";
pair[9] = "<?php echo $_POST[ans9];?>";
pair[10] = "<?php echo $_POST[ans10];?>";
pair[11] = "<?php echo $_POST[ans11];?>";
pair[12] = "<?php echo $_POST[ans12];?>";

for (ii = 1; ii < 13; ii++){
    pair[ii] = parseInt(pair[ii], 10);
}



//document.getElementById("submitButton").disabled = true;
//document.getElementById("ans").style.visibility = 'hidden';

drawDots();
drawAns();


function drawDots(){

    var i;

    for (i = 1; i < 13; i++){

    ctx.beginPath();
    ctx.arc(2, 94+84*(i-1) , 1, 0, 2 * Math.PI);
    ctx.fillStyle = "#000000";
    ctx.fill();
    ctx.stroke();

    }

    for (i = 13; i < 25; i++){

    ctx.beginPath();
    ctx.arc(192, 94+84*(i-13) , 1, 0, 2 * Math.PI);
    ctx.fillStyle = "#000000";
    ctx.fill();
    ctx.stroke();

    }


}


function drawAns(){

	var i;
	for (i = 1; i < 13; i++){

		if (pair[i] === ans[i]){

                ctx.beginPath();
                ctx.moveTo(0, 94+84*(i-1));
                ctx.lineTo(192, 94+84*(pair[i]-13));
		ctx.strokeStyle = "#00e600";
                ctx.stroke();
		ctx.closePath();
		}

		if (pair[i] != ans[i]){
                ctx.beginPath();
                ctx.moveTo(0, 94+84*(i-1));
                ctx.lineTo(192, 94+84*(pair[i]-13));
		        ctx.strokeStyle = "#FF0000";
                ctx.stroke();
                ctx.closePath();

                ctx.beginPath();
                ctx.moveTo(0, 94+84*(i-1));
                ctx.lineTo(192, 94+84*(ans[i]-13));
                ctx.strokeStyle = "#00e600";
                ctx.stroke();
                ctx.closePath();

		}
	}

}

</script>


</body>
</html>

