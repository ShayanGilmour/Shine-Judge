#include <bits/stdc++.h>
using namespace std;

int main()
{
	double a, b;
	cin >> a >> b;
	if (abs(a-b) < 1e-5){}
	else
		system("echo 1 >> badanswer");
}
