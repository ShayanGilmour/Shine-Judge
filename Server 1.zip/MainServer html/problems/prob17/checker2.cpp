#include <bits/stdc++.h>
using namespace std;
int main()
{
	long double d;
	cin >> d;
	if ((1-d) < 1e-3)
		system("touch goodanswer");
}
