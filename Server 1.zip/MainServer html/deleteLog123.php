<html>
<body>


<?php
    shell_exec("echo started > Log18455");
?>

</body>
</html>
