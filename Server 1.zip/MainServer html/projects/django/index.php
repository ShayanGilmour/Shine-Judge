<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Shine Judge</title>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
    <link rel="stylesheet" type="text/css" media="screen" href="/css/mainV5.css">
    <!-- <script src="main.js"></script> -->
    <link rel="shortcut icon" href="/pictures/logo_favicon.png">

</head>
<script>
function goBack() {
    window.history.back();
}
</script>
<body>
    <div class="header">
        <h1>Shine Judge</h1>
    </div>
    <div class="container">
        <div class="blank"></div>
        <div class="MediumLogo">
            <a>
            <img src="/pictures/logo_main.png" onclick="goBack()">
            </a>
        </div>

        <center><font size=6 style="font-family: 'Times New Roman'"><b>Django Project</b></font></center><br>

        <div class="box">
            <div class="box header">
                <h2 style="font-size: 22px;">Input</h2>
            </div>
            <div class="box main" style="margin-bottom: 15px">
        	<div class="codeInput">
		    <a href="statement.jpg"><font color="000"><b>Statement</b></font></a><br>
                    <br><a href="fileuploader.urls.py" download>fileuploader/urls.py</a>&emsp; 
			<a href="fileuploader.views.py" download>fileuploader/views.py</a> &emsp;
			<a href="shalgham.urls.py" download>shalgham/urls.py</a>
			<br><br>
			<center><font size=5>
			<?php $text = file_get_contents("tutorial"); $text=str_replace("\n","<br />",$text); echo "<td align=centre>$text</td>"; shell_exec("rm tutorial");?>
			</center><br></font>

	        </div>
	        <div class="submitpart">
	            <form action="tofile.php" method="post">
	                <center>
<!--			<font size=5><b>Tiny Tutorial... So far:</b><br></font> -->
	                Username:<br><input type="text" name="username"><br>Password:<br><input type="password" name="password">
	                </center>
	                <input class="submitbutton" type="submit" value="Display">
	            </form>
	        </div>

            </div>
        </div>

        <div class="blank"></div>
    </div>




</body></html>
