#!/bin/bash

for ((i=1; i<16; i++))
do

	touch input$i

done

